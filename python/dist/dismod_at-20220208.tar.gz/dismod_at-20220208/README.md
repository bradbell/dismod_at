# Install dismod_at python sub-package

See ../readme.md for dismod_at the package readme file.
